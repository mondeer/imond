<?php $__env->startSection('content'); ?>
  <h1>Send Message</h1>
  <div class="panel-body">
      <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/imond/sms')); ?>">
          <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="tel" class="col-md-4 control-label">Phone Number</label>

            <div class="col-md-6">
                <input id="tel" type="text" class="form-control" name="mobile"
                       placeholder="e.g +2567______" required>
            </div>

        </div>

        <div class="form-group">
            <label for="message" class="col-md-4 control-label">Message</label>

            <div class="col-md-6">
                    <textarea name="message" id="message" cols="30" rows="10" class="form-control"
                              placeholder="message"
                              required autofocus></textarea>
            </div>
        </div>

        <div class="form-group">
            <div class="col-md-8 col-md-offset-4">
                <button type="submit" class="btn btn-primary">
                    Send Message
                </button>

            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.imondmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>