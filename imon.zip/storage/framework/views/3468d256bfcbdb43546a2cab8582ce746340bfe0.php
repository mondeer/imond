<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="sub-title">
 		<a href="/imondblog" title="Go to Home Page"><h2>Back Home</h2></a>
      <a href="#" class="smoth-scroll"><i class="icon-bubbles"></i></a>
   </div>

  <div class="col-md-10 col-md-offset-2">
      <h1><?php echo e($blog->title); ?></h1>
      <p>
        By <?php echo e($blog->author); ?>

      </p>
              <p> Created: <?php echo e($blog->created_at->diffForHumans()); ?></p>
            <p>
                <span class="fa fa-clock-o"></span> <?php echo e(Carbon\Carbon::parse($blog->created_at)->format('d-m-Y')); ?>

            </p>
            <hr>
          <p class="lead imondblog" align="justify">
              <?php echo $blog->content; ?>

          </p>

  </div>
  <hr>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('blog.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>